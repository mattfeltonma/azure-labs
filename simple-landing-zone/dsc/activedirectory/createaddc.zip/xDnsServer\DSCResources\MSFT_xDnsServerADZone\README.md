# Description

The xDnsServerADZone DSC resource manages an AD integrated zone on a Domain Name System (DNS) server.
